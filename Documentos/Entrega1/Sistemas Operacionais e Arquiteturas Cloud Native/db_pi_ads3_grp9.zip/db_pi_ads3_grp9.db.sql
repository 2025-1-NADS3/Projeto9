BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "fecap_users" (
	"first_name"	TEXT NOT NULL,
	"last_name"	TEXT NOT NULL,
	"email"	TEXT NOT NULL UNIQUE,
	"ra"	INTEGER NOT NULL UNIQUE,
	PRIMARY KEY("ra")
);
CREATE TABLE IF NOT EXISTS "fecap_aut" (
	"ra"	INTEGER NOT NULL UNIQUE,
	"psw"	TEXT NOT NULL,
	PRIMARY KEY("ra"),
	FOREIGN KEY("ra") REFERENCES "fecap_users"("ra")
);
COMMIT;
