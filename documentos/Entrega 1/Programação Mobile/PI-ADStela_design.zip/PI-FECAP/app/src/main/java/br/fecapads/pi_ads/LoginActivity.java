package br.fecapads.pi_ads;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "AutenticacaoLogin"; // Tag usada para exibir mensagens no Logcat

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Referências aos elementos do layout
        EditText etUsername = findViewById(R.id.etLoginUsername);
        EditText etPassword = findViewById(R.id.etLoginPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        // Instância da classe interna DatabaseHelper
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Chamar a função para listar todos os dados armazenados no banco de dados
        logAllUsers(dbHelper);

        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (!username.isEmpty() && !password.isEmpty()) {
                // Autenticação do usuário
                SQLiteDatabase db = dbHelper.getReadableDatabase();
                Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME +
                                " WHERE " + DatabaseHelper.COLUMN_USERNAME + " = ? AND " + DatabaseHelper.COLUMN_PASSWORD + " = ?",
                        new String[]{username, password});

                if (cursor.moveToFirst()) {
                    // Log de sucesso no login
                    Log.d(TAG, "Login bem-sucedido para o usuário: " + username);
                    Toast.makeText(this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                } else {
                    // Log de falha no login
                    Log.w(TAG, "Falha no login: Usuário ou senha incorretos. Usuário: " + username);
                    Toast.makeText(this, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show();
                }
                cursor.close();
                db.close();
            } else {
                // Log de campos vazios
                Log.e(TAG, "Erro: Campos de login não preenchidos!");
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Função para listar todos os usuários no banco e exibir no Logcat
    private void logAllUsers(DatabaseHelper dbHelper) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));
                String username = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_USERNAME));
                String password = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PASSWORD));

                Log.d(TAG, "ID: " + id + ", Usuário: " + username + ", Senha: " + password);
            } while (cursor.moveToNext());
        } else {
            Log.d(TAG, "Nenhum dado encontrado no banco de dados.");
        }
        cursor.close();
        db.close();
    }

    // Classe interna para gerenciar o banco de dados
    private static class DatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "UserDatabase";
        private static final int DATABASE_VERSION = 2; // Versão do banco de dados

        public static final String TABLE_NAME = "users";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_USERNAME = "username";
        public static final String COLUMN_PASSWORD = "password";

        private static final String CREATE_TABLE =
                "CREATE TABLE " + TABLE_NAME + "(" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USERNAME + " TEXT NOT NULL, " +
                        COLUMN_PASSWORD + " TEXT NOT NULL);";

        public DatabaseHelper(android.content.Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_TABLE);
            Log.d(TAG, "Banco de dados criado com sucesso e tabela inicial configurada."); // Log confirmação
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.d(TAG, "Atualizando banco de dados de versão " + oldVersion + " para " + newVersion);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db); // Recria o banco de dados
        }
    }
}
