package br.fecapads.pi_entrega;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private MainActivity.DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new MainActivity.DatabaseHelper(this);

        EditText editEmail = findViewById(R.id.edit_email);
        EditText editPassword = findViewById(R.id.edit_password);
        Button btnLogin = findViewById(R.id.btn_login);
        TextView tvSignupLink = findViewById(R.id.tv_signup_link);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editEmail.getText().toString();
                String password = editPassword.getText().toString();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isAuthenticated = authenticateUser(email, password);
                    if (isAuthenticated) {
                        Toast.makeText(LoginActivity.this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                        Log.d("LoginActivity", "Usuário autenticado: " + email);
                        // Redirecione para a próxima tela ou funcionalidade
                    } else {
                        Toast.makeText(LoginActivity.this, "Email ou senha incorretos.", Toast.LENGTH_SHORT).show();
                        Log.e("LoginActivity", "Falha na autenticação: " + email);
                    }
                }
            }
        });

        tvSignupLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirecionar para a tela de cadastro
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean authenticateUser(String email, String password) {
        Cursor cursor = databaseHelper.getReadableDatabase().rawQuery(
                "SELECT * FROM Users WHERE name = ? AND password = ?",
                new String[]{email, password});

        boolean isAuthenticated = cursor.getCount() > 0;
        cursor.close();
        return isAuthenticated;
    }
}
