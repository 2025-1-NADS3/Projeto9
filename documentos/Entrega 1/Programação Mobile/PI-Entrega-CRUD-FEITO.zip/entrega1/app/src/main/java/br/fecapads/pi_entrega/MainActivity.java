package br.fecapads.pi_entrega;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        EditText editName = findViewById(R.id.edit_name);
        EditText editPassword = findViewById(R.id.edit_password);
        Button btnSignUp = findViewById(R.id.btn_sign_up);
        TextView tvLoginLink = findViewById(R.id.tv_login_link);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString();
                String password = editPassword.getText().toString();

                if (name.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isInserted = databaseHelper.addUser(name, password);
                    if (isInserted) {
                        Toast.makeText(MainActivity.this, "Usuário registrado com sucesso!", Toast.LENGTH_SHORT).show();
                        Log.d("DatabaseHelper", "Dados inseridos com sucesso: Nome=" + name + ", Senha=" + password);
                        editName.setText("");
                        editPassword.setText("");

                        // Mostra os dados armazenados no banco
                        databaseHelper.getAllUsers();
                    } else {
                        Toast.makeText(MainActivity.this, "Erro ao registrar o usuário.", Toast.LENGTH_SHORT).show();
                        Log.e("DatabaseHelper", "Erro ao inserir dados no banco.");
                    }
                }
            }
        });

        tvLoginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirecionar para a tela de login
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    // Classe de ajuda para banco de dados SQLite
    public static class DatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "UserDatabase.db";
        private static final int DATABASE_VERSION = 1;

        private static final String TABLE_USERS = "Users";
        private static final String COLUMN_ID = "id";
        private static final String COLUMN_NAME = "name";
        private static final String COLUMN_PASSWORD = "password";

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String createTable = "CREATE TABLE " + TABLE_USERS + " ("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_NAME + " TEXT, "
                    + COLUMN_PASSWORD + " TEXT)";
            db.execSQL(createTable);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            onCreate(db);
        }

        public boolean addUser(String name, String password) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, name);
            values.put(COLUMN_PASSWORD, password);

            long result = db.insert(TABLE_USERS, null, values);
            db.close();
            return result != -1;
        }

        public void getAllUsers() {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.query(TABLE_USERS, null, null, null, null, null, null);

            if (cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                    String password = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD));
                    Log.d("DatabaseHelper", "Usuário encontrado: ID=" + id + ", Nome=" + name + ", Senha=" + password);
                } while (cursor.moveToNext());
            } else {
                Log.d("DatabaseHelper", "Nenhum usuário encontrado no banco de dados.");
            }
            cursor.close();
            db.close();
        }
    }
}
