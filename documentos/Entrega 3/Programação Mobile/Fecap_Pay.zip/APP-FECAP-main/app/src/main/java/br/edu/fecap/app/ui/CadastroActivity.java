package br.edu.fecap.app.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import br.edu.fecap.app.R;
import br.edu.fecap.app.database.FirebaseHelper;
import br.edu.fecap.app.model.Usuario;

public class CadastroActivity extends AppCompatActivity {

    private TextInputEditText etNome;
    private TextInputEditText etEmail;
    private TextInputEditText etMatricula;
    private TextInputEditText etSenha;
    private TextInputEditText etConfirmarSenha;
    private Button btnCadastrar;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        // Inicializar componentes
        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etMatricula = findViewById(R.id.etMatricula);
        etSenha = findViewById(R.id.etSenha);
        etConfirmarSenha = findViewById(R.id.etConfirmarSenha);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        btnVoltar = findViewById(R.id.btnVoltar);

        // Configurar listener do botão de cadastro
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validarFormulario()) {
                    // Realizar cadastro
                    realizarCadastro();
                }
            }
        });

        // Configurar listener do botão voltar
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Voltar para a tela anterior
            }
        });
    }

    private boolean validarFormulario() {
        String nome = etNome.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String matricula = etMatricula.getText().toString().trim();
        String senha = etSenha.getText().toString();
        String confirmarSenha = etConfirmarSenha.getText().toString();

        // Validar campos vazios
        if (nome.isEmpty()) {
            etNome.setError("Por favor, insira seu nome");
            return false;
        }

        if (email.isEmpty()) {
            etEmail.setError("Por favor, insira seu e-mail");
            return false;
        }

        if (matricula.isEmpty()) {
            etMatricula.setError("Por favor, insira sua matrícula");
            return false;
        }

        if (senha.isEmpty()) {
            etSenha.setError("Por favor, insira uma senha");
            return false;
        }

        if (confirmarSenha.isEmpty()) {
            etConfirmarSenha.setError("Por favor, confirme sua senha");
            return false;
        }

        // Validar formato de e-mail
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Insira um e-mail válido");
            return false;
        }

        // Validar se é e-mail institucional (termina com @fecap.br)
        if (!email.endsWith("@fecap.br")) {
            etEmail.setError("Insira um e-mail institucional (@fecap.br)");
            return false;
        }

        // Validar se senhas conferem
        if (!senha.equals(confirmarSenha)) {
            etConfirmarSenha.setError("As senhas não coincidem");
            return false;
        }

        // Validar tamanho da senha
        if (senha.length() < 6) {
            etSenha.setError("A senha deve ter pelo menos 6 caracteres");
            return false;
        }

        return true;
    }

    private void realizarCadastro() {
        // Obter dados do formulário
        String nome = etNome.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String matricula = etMatricula.getText().toString().trim();
        String senha = etSenha.getText().toString();

        // Desabilitar botão de cadastro
        btnCadastrar.setEnabled(false);
        btnCadastrar.setText(R.string.cadastrando);

        // Verificar se a matrícula já existe
        FirebaseHelper.getInstance().verificarMatricula(matricula)
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        // Matrícula já existe
                        etMatricula.setError("Esta matrícula já está cadastrada");
                        btnCadastrar.setEnabled(true);
                        btnCadastrar.setText(R.string.cadastrar);
                        return;
                    }

                    // Matrícula disponível, prosseguir com o cadastro
                    FirebaseHelper.getInstance().cadastrarUsuario(email, senha)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    // Cadastro de autenticação bem-sucedido
                                    // Agora salvar os dados do usuário no Firestore
                                    Usuario novoUsuario = new Usuario();
                                    novoUsuario.setNome(nome);
                                    novoUsuario.setEmail(email);
                                    novoUsuario.setMatricula(matricula);

                                    FirebaseHelper.getInstance().salvarUsuario(novoUsuario)
                                            .addOnSuccessListener(aVoid -> {
                                                Toast.makeText(CadastroActivity.this,
                                                        "Cadastro realizado com sucesso!",
                                                        Toast.LENGTH_SHORT).show();
                                                finish(); // Voltar para a tela de login
                                            })
                                            .addOnFailureListener(e -> {
                                                Toast.makeText(CadastroActivity.this,
                                                        "Erro ao salvar dados: " + e.getMessage(),
                                                        Toast.LENGTH_SHORT).show();
                                                btnCadastrar.setEnabled(true);
                                                btnCadastrar.setText(R.string.cadastrar);
                                            });
                                } else {
                                    // Falha no cadastro
                                    String errorMsg = "Falha ao realizar cadastro";
                                    if (task.getException() != null) {
                                        errorMsg = task.getException().getMessage();
                                    }
                                    Toast.makeText(CadastroActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                                    btnCadastrar.setEnabled(true);
                                    btnCadastrar.setText(R.string.cadastrar);
                                }
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(CadastroActivity.this,
                            "Erro ao verificar matrícula: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    btnCadastrar.setEnabled(true);
                    btnCadastrar.setText(R.string.cadastrar);
                });
    }
}