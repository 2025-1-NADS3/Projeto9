package br.edu.fecap.app.model;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.Exclude;
import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;

public class Emprestimo {
    @DocumentId
    private String id; // Atualizado para String para compatibilidade com Firestore
    private String idUsuario; // ID do usuário que pegou o livro emprestado
    private String idLivro; // ID do livro emprestado
    private Date dataEmprestimo; // Data em que o livro foi emprestado
    private Date dataDevolucaoPrevista; // Data prevista para devolução
    private Date dataDevolucaoEfetiva; // Data efetiva da devolução (pode ser nula)
    private String status; // "ATIVO", "DEVOLVIDO", "ATRASADO"

    // Campos transientes para mapeamento
    @Exclude
    private Livro livro; // Objeto livro relacionado (não armazenado no Firestore)

    // Construtor vazio necessário para o Firestore
    public Emprestimo() {
    }

    // Construtor completo
    public Emprestimo(String id, String idUsuario, String idLivro,
                      Date dataEmprestimo, Date dataDevolucaoPrevista,
                      Date dataDevolucaoEfetiva, String status) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucaoPrevista = dataDevolucaoPrevista;
        this.dataDevolucaoEfetiva = dataDevolucaoEfetiva;
        this.status = status;
    }

    // Construtor para novos empréstimos (sem ID e data de devolução efetiva)
    public Emprestimo(String idUsuario, String idLivro,
                      Date dataEmprestimo, Date dataDevolucaoPrevista) {
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucaoPrevista = dataDevolucaoPrevista;
        this.status = "ATIVO";
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(String idLivro) {
        this.idLivro = idLivro;
    }

    public Date getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(Date dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public Date getDataDevolucaoPrevista() {
        return dataDevolucaoPrevista;
    }

    public void setDataDevolucaoPrevista(Date dataDevolucaoPrevista) {
        this.dataDevolucaoPrevista = dataDevolucaoPrevista;
    }

    public Date getDataDevolucaoEfetiva() {
        return dataDevolucaoEfetiva;
    }

    public void setDataDevolucaoEfetiva(Date dataDevolucaoEfetiva) {
        this.dataDevolucaoEfetiva = dataDevolucaoEfetiva;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Getters e Setters para campos transientes (excluídos do Firestore)
    @Exclude
    public Livro getLivro() {
        return livro;
    }

    @Exclude
    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    // Método auxiliar para verificar se o empréstimo está atrasado
    @Exclude
    public boolean isAtrasado() {
        if ("DEVOLVIDO".equals(status)) {
            return false;
        }

        Date hoje = new Date();
        return hoje.after(dataDevolucaoPrevista);
    }

    // Método auxiliar para atualizar status baseado na data
    @Exclude
    public void atualizarStatus() {
        if ("DEVOLVIDO".equals(status)) {
            return;
        }

        if (isAtrasado()) {
            status = "ATRASADO";
        } else {
            status = "ATIVO";
        }
    }
}