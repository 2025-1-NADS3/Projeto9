package br.edu.fecap.app.database;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import br.edu.fecap.app.model.Usuario;

public class FirebaseHelper {

    private static FirebaseHelper instance;
    private final FirebaseAuth auth;
    private final FirebaseFirestore db;

    private FirebaseHelper() {
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
    }

    public static synchronized FirebaseHelper getInstance() {
        if (instance == null) {
            instance = new FirebaseHelper();
        }
        return instance;
    }

    // Referências para coleções
    public CollectionReference getUsuariosRef() {
        return db.collection("usuarios");
    }

    public CollectionReference getLivrosRef() {
        return db.collection("livros");
    }

    public CollectionReference getEmprestimosRef() {
        return db.collection("emprestimos");
    }

    public CollectionReference getBoletosRef() {
        return db.collection("boletos");
    }

    // Métodos de autenticação
    public Task<AuthResult> cadastrarUsuario(String email, String senha) {
        return auth.createUserWithEmailAndPassword(email, senha);
    }

    public Task<AuthResult> fazerLogin(String email, String senha) {
        return auth.signInWithEmailAndPassword(email, senha);
    }

    public void fazerLogout() {
        auth.signOut();
    }

    public FirebaseUser getUsuarioAtual() {
        return auth.getCurrentUser();
    }

    // Métodos para usuários
    public Task<Void> salvarUsuario(Usuario usuario) {
        Map<String, Object> dados = new HashMap<>();
        dados.put("nome", usuario.getNome());
        dados.put("email", usuario.getEmail());
        dados.put("matricula", usuario.getMatricula());

        // Usar o UID do Firebase Auth como ID do documento
        String uid = getUsuarioAtual().getUid();
        return getUsuariosRef().document(uid).set(dados);
    }

    public Task<DocumentSnapshot> getUsuarioPorUID(String uid) {
        return getUsuariosRef().document(uid).get();
    }

    // Métodos para verificar se matrícula já existe
    public Task<QuerySnapshot> verificarMatricula(String matricula) {
        return getUsuariosRef().whereEqualTo("matricula", matricula).get();
    }

    // Novo método para reservar livro
    public Task<DocumentReference> reservarLivro(String livroId, String usuarioId) {
        Map<String, Object> dadosEmprestimo = new HashMap<>();
        dadosEmprestimo.put("livroId", livroId);
        dadosEmprestimo.put("usuarioId", usuarioId);
        dadosEmprestimo.put("dataEmprestimo", com.google.firebase.Timestamp.now());

        // Define a data de devolução prevista para 15 dias no futuro
        long millis15Dias = 15L * 24 * 60 * 60 * 1000;
        dadosEmprestimo.put("dataDevolucaoPrevista", new Date(System.currentTimeMillis() + millis15Dias));
        dadosEmprestimo.put("status", "ativo");

        return getEmprestimosRef().add(dadosEmprestimo).addOnSuccessListener(documentReference -> {
            // Marca o livro como indisponível
            getLivrosRef().document(livroId).update("disponivel", false);
        });
    }
}
