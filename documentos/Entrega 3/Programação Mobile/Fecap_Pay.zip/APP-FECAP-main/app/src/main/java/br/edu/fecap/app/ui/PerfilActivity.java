package br.edu.fecap.app.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.HashMap;
import java.util.Map;

import br.edu.fecap.app.R;
import br.edu.fecap.app.database.FirebaseHelper;
import br.edu.fecap.app.model.Usuario;

public class PerfilActivity extends AppCompatActivity {

    private TextView tvNomeUsuario;
    private TextView tvMatricula;
    private TextInputEditText etNome;
    private TextInputEditText etEmail;
    private TextInputEditText etSenhaAtual;
    private TextInputEditText etNovaSenha;
    private TextInputEditText etConfirmarSenha;
    private Button btnSalvar;
    private ProgressBar progressBar;

    private String usuarioId;
    private Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        // Obter ID do usuário
        usuarioId = getIntent().getStringExtra("USUARIO_ID");

        // Configurar toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Inicializar componentes
        tvNomeUsuario = findViewById(R.id.tvNomeUsuario);
        tvMatricula = findViewById(R.id.tvMatricula);
        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etSenhaAtual = findViewById(R.id.etSenhaAtual);
        etNovaSenha = findViewById(R.id.etNovaSenha);
        etConfirmarSenha = findViewById(R.id.etConfirmarSenha);
        btnSalvar = findViewById(R.id.btnSalvar);
        progressBar = findViewById(R.id.progressBar);

        // Configurar listener do botão salvar
        btnSalvar.setOnClickListener(v -> {
            if (validarFormulario()) {
                salvarAlteracoes();
            }
        });

        // Carregar dados do usuário
        carregarDadosUsuario();
    }

    private void carregarDadosUsuario() {
        // Mostrar progresso
        progressBar.setVisibility(View.VISIBLE);

        // Carregar dados do usuário do Firestore
        FirebaseHelper.getInstance().getUsuarioPorUID(usuarioId)
                .addOnSuccessListener(documentSnapshot -> {
                    progressBar.setVisibility(View.GONE);

                    if (documentSnapshot.exists()) {
                        // Converter documento para objeto Usuario
                        usuario = documentSnapshot.toObject(Usuario.class);

                        // Garantir que o ID está definido
                        if (usuario != null) {
                            usuario.setId(usuarioId);

                            // Preencher campos com dados do usuário
                            tvNomeUsuario.setText(usuario.getNome());
                            tvMatricula.setText("Matrícula: " + usuario.getMatricula());
                            etNome.setText(usuario.getNome());
                            etEmail.setText(usuario.getEmail());
                        }
                    } else {
                        Toast.makeText(PerfilActivity.this,
                                "Usuário não encontrado",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(PerfilActivity.this,
                            "Erro ao carregar dados do usuário: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();

                    // Usando dados simulados em caso de erro
                    usuario = new Usuario();
                    usuario.setId(usuarioId);
                    usuario.setNome("Estudante FECAP");
                    usuario.setEmail("estudante@fecap.br");
                    usuario.setMatricula("202500001");

                    // Preencher campos
                    tvNomeUsuario.setText(usuario.getNome());
                    tvMatricula.setText("Matrícula: " + usuario.getMatricula());
                    etNome.setText(usuario.getNome());
                    etEmail.setText(usuario.getEmail());
                });
    }

    private boolean validarFormulario() {
        String nome = etNome.getText().toString().trim();
        String senhaAtual = etSenhaAtual.getText().toString();
        String novaSenha = etNovaSenha.getText().toString();
        String confirmarSenha = etConfirmarSenha.getText().toString();

        // Validar nome
        if (nome.isEmpty()) {
            etNome.setError("Por favor, insira seu nome");
            return false;
        }

        // Se algum campo de senha estiver preenchido, todos devem estar
        boolean algumCampoSenhaPreenchido = !senhaAtual.isEmpty() || !novaSenha.isEmpty() || !confirmarSenha.isEmpty();
        boolean todosCamposSenhaPreenchidos = !senhaAtual.isEmpty() && !novaSenha.isEmpty() && !confirmarSenha.isEmpty();

        if (algumCampoSenhaPreenchido && !todosCamposSenhaPreenchidos) {
            if (senhaAtual.isEmpty()) {
                etSenhaAtual.setError("Por favor, insira sua senha atual");
            }
            if (novaSenha.isEmpty()) {
                etNovaSenha.setError("Por favor, insira a nova senha");
            }
            if (confirmarSenha.isEmpty()) {
                etConfirmarSenha.setError("Por favor, confirme a nova senha");
            }
            return false;
        }

        // Validar se as novas senhas conferem
        if (todosCamposSenhaPreenchidos && !novaSenha.equals(confirmarSenha)) {
            etConfirmarSenha.setError("As senhas não coincidem");
            return false;
        }

        // Validar tamanho da nova senha
        if (todosCamposSenhaPreenchidos && novaSenha.length() < 6) {
            etNovaSenha.setError("A senha deve ter pelo menos 6 caracteres");
            return false;
        }

        return true;
    }

    private void salvarAlteracoes() {
        // Obter valores dos campos
        String nome = etNome.getText().toString().trim();
        String senhaAtual = etSenhaAtual.getText().toString();
        String novaSenha = etNovaSenha.getText().toString();

        // Verificar se houve alterações
        boolean alterouNome = !nome.equals(usuario.getNome());
        boolean alterouSenha = !TextUtils.isEmpty(senhaAtual);

        if (!alterouNome && !alterouSenha) {
            Toast.makeText(this, "Nenhuma alteração realizada", Toast.LENGTH_SHORT).show();
            return;
        }

        // Mostrar progresso
        progressBar.setVisibility(View.VISIBLE);
        btnSalvar.setEnabled(false);

        // Processar alterações de perfil
        if (alterouNome) {
            // Atualizar nome no Firestore
            Map<String, Object> updates = new HashMap<>();
            updates.put("nome", nome);

            FirebaseHelper.getInstance().getUsuariosRef().document(usuarioId)
                    .update(updates)
                    .addOnSuccessListener(aVoid -> {
                        // Nome atualizado com sucesso
                        usuario.setNome(nome);
                        tvNomeUsuario.setText(nome);

                        // Se não tem também alteração de senha, concluir
                        if (!alterouSenha) {
                            progressBar.setVisibility(View.GONE);
                            btnSalvar.setEnabled(true);
                            Toast.makeText(PerfilActivity.this,
                                    "Alterações salvas com sucesso",
                                    Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        progressBar.setVisibility(View.GONE);
                        btnSalvar.setEnabled(true);
                        Toast.makeText(PerfilActivity.this,
                                "Erro ao atualizar nome: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    });
        }

        // Processar alteração de senha
        if (alterouSenha) {
            // Atualizar senha no Firebase Auth
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

            if (user != null && user.getEmail() != null) {
                // Reautenticar usuário
                FirebaseHelper.getInstance().fazerLogin(user.getEmail(), senhaAtual)
                        .addOnSuccessListener(authResult -> {
                            // Senha atual correta, atualizar para nova senha
                            user.updatePassword(novaSenha)
                                    .addOnSuccessListener(aVoid -> {
                                        progressBar.setVisibility(View.GONE);
                                        btnSalvar.setEnabled(true);

                                        // Limpar campos de senha
                                        etSenhaAtual.setText("");
                                        etNovaSenha.setText("");
                                        etConfirmarSenha.setText("");

                                        Toast.makeText(PerfilActivity.this,
                                                "Alterações salvas com sucesso",
                                                Toast.LENGTH_SHORT).show();
                                    })
                                    .addOnFailureListener(e -> {
                                        progressBar.setVisibility(View.GONE);
                                        btnSalvar.setEnabled(true);
                                        Toast.makeText(PerfilActivity.this,
                                                "Erro ao atualizar senha: " + e.getMessage(),
                                                Toast.LENGTH_SHORT).show();
                                    });
                        })
                        .addOnFailureListener(e -> {
                            progressBar.setVisibility(View.GONE);
                            btnSalvar.setEnabled(true);
                            etSenhaAtual.setError("Senha atual incorreta");
                            Toast.makeText(PerfilActivity.this,
                                    "Senha atual incorreta",
                                    Toast.LENGTH_SHORT).show();
                        });
            } else {
                progressBar.setVisibility(View.GONE);
                btnSalvar.setEnabled(true);
                Toast.makeText(PerfilActivity.this,
                        "Erro ao autenticar usuário",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}