package br.edu.fecap.app.ui.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.edu.fecap.app.R;
import br.edu.fecap.app.api.ApiMock;
import br.edu.fecap.app.database.FirebaseHelper;
import br.edu.fecap.app.model.Livro;

public class LivrosFragment extends Fragment {

    private static final String ARG_USUARIO_ID = "usuarioId";

    private String usuarioId;
    private RecyclerView rvLivros;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private List<Livro> livros = new ArrayList<>();
    private LivrosAdapter adapter;

    public LivrosFragment() {}

    public static LivrosFragment newInstance(String usuarioId) {
        LivrosFragment fragment = new LivrosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_USUARIO_ID, usuarioId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            usuarioId = getArguments().getString(ARG_USUARIO_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_livros, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvLivros = view.findViewById(R.id.rvLivros);
        progressBar = view.findViewById(R.id.progressBar);
        tvEmpty = view.findViewById(R.id.tvEmpty);

        rvLivros.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new LivrosAdapter(livros, this::reservarLivro);
        rvLivros.setAdapter(adapter);

        carregarLivros();
    }

    private void carregarLivros() {
        // Mostrar progresso
        progressBar.setVisibility(View.VISIBLE);
        rvLivros.setVisibility(View.GONE);
        tvEmpty.setVisibility(View.GONE);

        // Buscar livros no Firestore
        FirebaseHelper.getInstance().getLivrosRef()
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    // Processar resultados
                    livros.clear();

                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        try {
                            Livro livro = document.toObject(Livro.class);
                            if (livro != null) {
                                // Salvar o ID do documento no livro
                                livro.setId(document.getId());
                                livros.add(livro);

                                // Adicionar log para depuração
                                Log.d("LivrosFragment", "Livro carregado: " + livro.getTitulo()
                                        + ", ID: " + livro.getId()
                                        + ", Disponível: " + livro.isDisponivel());
                            }
                        } catch (Exception e) {
                            Log.e("LivrosFragment", "Erro ao converter documento para Livro: "
                                    + e.getMessage());
                            e.printStackTrace();
                        }
                    }

                    // Atualizar UI
                    progressBar.setVisibility(View.GONE);

                    if (livros.isEmpty()) {
                        Log.w("LivrosFragment", "Nenhum livro encontrado no Firestore, usando dados mock");
                        // Usar dados mock se não encontrou nada
                        livros.addAll(ApiMock.getLivrosMock());
                    }

                    adapter.notifyDataSetChanged();

                    if (livros.isEmpty()) {
                        tvEmpty.setVisibility(View.VISIBLE);
                        rvLivros.setVisibility(View.GONE);
                    } else {
                        tvEmpty.setVisibility(View.GONE);
                        rvLivros.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("LivrosFragment", "Erro ao carregar livros: " + e.getMessage());
                    e.printStackTrace();

                    progressBar.setVisibility(View.GONE);

                    // Em caso de erro, usar dados mock
                    livros.clear();
                    livros.addAll(ApiMock.getLivrosMock());
                    adapter.notifyDataSetChanged();

                    if (livros.isEmpty()) {
                        tvEmpty.setVisibility(View.VISIBLE);
                        rvLivros.setVisibility(View.GONE);
                    } else {
                        tvEmpty.setVisibility(View.GONE);
                        rvLivros.setVisibility(View.VISIBLE);
                    }

                    Toast.makeText(getContext(),
                            "Erro ao carregar livros: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }
    private void reservarLivro(Livro livro) {
        if (!livro.isDisponivel()) {
            Toast.makeText(getContext(), "Este livro não está disponível para reserva", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        Map<String, Object> emprestimoData = new HashMap<>();
        emprestimoData.put("idUsuario", usuarioId);
        emprestimoData.put("idLivro", livro.getId());
        emprestimoData.put("dataEmprestimo", new Date());

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 15);
        emprestimoData.put("dataDevolucaoPrevista", calendar.getTime());
        emprestimoData.put("status", "ATIVO");

        FirebaseFirestore.getInstance().runTransaction(transaction -> {
            transaction.update(
                    FirebaseHelper.getInstance().getLivrosRef().document(livro.getId()),
                    "disponivel", false
            );

            transaction.set(
                    FirebaseHelper.getInstance().getEmprestimosRef().document(),
                    emprestimoData
            );

            return null;
        }).addOnSuccessListener(aVoid -> {
            progressBar.setVisibility(View.GONE);

            livro.setDisponivel(false);
            int pos = livros.indexOf(livro);
            if (pos != -1) {
                adapter.notifyItemChanged(pos);
            }

            Toast.makeText(getContext(), "Livro reservado com sucesso!", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(getContext(),
                    "Erro ao reservar livro: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        });
    }

    // Adapter completo
    private static class LivrosAdapter extends RecyclerView.Adapter<LivrosAdapter.LivroViewHolder> {

        private final List<Livro> livros;
        private final OnReservarClickListener listener;

        public interface OnReservarClickListener {
            void onReservarClick(Livro livro);
        }

        public LivrosAdapter(List<Livro> livros, OnReservarClickListener listener) {
            this.livros = livros;
            this.listener = listener;
        }

        @NonNull
        @Override
        public LivroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_livro, parent, false);
            return new LivroViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull LivroViewHolder holder, int position) {
            holder.bind(livros.get(position), listener);
        }

        @Override
        public int getItemCount() {
            return livros.size();
        }

        static class LivroViewHolder extends RecyclerView.ViewHolder {
            private final TextView tvTituloLivro;
            private final TextView tvAutorLivro;
            private final TextView tvDescricaoLivro;
            private final TextView tvStatusLivro;
            private final Button btnReservar;
            private final ImageView ivCapaLivro;

            public LivroViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTituloLivro = itemView.findViewById(R.id.tvTituloLivro);
                tvAutorLivro = itemView.findViewById(R.id.tvAutorLivro);
                tvDescricaoLivro = itemView.findViewById(R.id.tvDescricaoLivro);
                tvStatusLivro = itemView.findViewById(R.id.tvStatusLivro);
                btnReservar = itemView.findViewById(R.id.btnReservar);
                ivCapaLivro = itemView.findViewById(R.id.ivCapaLivro);
            }

            public void bind(Livro livro, OnReservarClickListener listener) {
                tvTituloLivro.setText(livro.getTitulo());
                tvAutorLivro.setText(livro.getAutor());
                tvDescricaoLivro.setText(livro.getDescricao());

                if (ivCapaLivro != null && livro.getImagemUrl() != null && !livro.getImagemUrl().isEmpty()) {
                    int resId = livro.getImageResourceId(itemView.getContext());
                    ivCapaLivro.setImageResource(resId != 0 ? resId : R.drawable.placeholder_book);
                }

                if (livro.isDisponivel()) {
                    tvStatusLivro.setText(R.string.disponivel);
                    tvStatusLivro.setTextColor(itemView.getContext().getColor(R.color.fecap_green));
                    btnReservar.setText("Reservar");
                    btnReservar.setEnabled(true);
                } else {
                    tvStatusLivro.setText(R.string.indisponivel);
                    tvStatusLivro.setTextColor(itemView.getContext().getColor(R.color.gray));
                    btnReservar.setText("Indisponível");
                    btnReservar.setEnabled(false);
                }

                btnReservar.setOnClickListener(v -> {
                    if (livro.isDisponivel()) {
                        listener.onReservarClick(livro);
                    }
                });
            }
        }
    }
}
