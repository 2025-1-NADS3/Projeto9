package br.edu.fecap.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import br.edu.fecap.app.model.Usuario;
import br.edu.fecap.app.ui.BibliotecaActivity;
import br.edu.fecap.app.ui.BoletosActivity;
import br.edu.fecap.app.ui.LoginActivity;
import br.edu.fecap.app.ui.PerfilActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvNomeUsuario;
    private CardView cardBiblioteca;
    private CardView cardBoletos;
    private CardView cardPerfil;
    private String usuarioId;
    private Usuario usuarioLogado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            // Limpar completamente as preferências antigas
            SharedPreferences prefs = getSharedPreferences("FECAPApp", MODE_PRIVATE);
            prefs.edit().clear().apply();

            // Configurar toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            // Inicializar componentes
            tvNomeUsuario = findViewById(R.id.tvNomeUsuario);
            cardBiblioteca = findViewById(R.id.cardBiblioteca);
            cardBoletos = findViewById(R.id.cardBoletos);
            cardPerfil = findViewById(R.id.cardPerfil);

            // Verificar se há usuário logado no Firebase
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            if (currentUser != null) {
                usuarioId = currentUser.getUid();

                // Salvar ID no novo formato
                prefs.edit().putString("USER_ID_STRING", usuarioId).apply();
            } else {
                // Usar um ID de desenvolvimento simulado
                usuarioId = "user123";

                // Salvar ID simulado
                prefs.edit().putString("USER_ID_STRING", usuarioId).apply();
            }

            // Carregar dados do usuário (simulado para desenvolvimento)
            usuarioLogado = new Usuario();
            usuarioLogado.setId(usuarioId);
            usuarioLogado.setNome("Estudante FECAP");
            usuarioLogado.setEmail("estudante@fecap.br");
            usuarioLogado.setMatricula("202500001");

            // Atualizar UI
            tvNomeUsuario.setText(usuarioLogado.getNome());

            // Mostrar toast indicando modo de desenvolvimento
            Toast.makeText(this, "Modo de desenvolvimento", Toast.LENGTH_SHORT).show();

            // Configurar click listeners
            configurarClickListeners();

        } catch (Exception e) {
            // Capturar qualquer exceção que ocorra durante a inicialização
            Toast.makeText(this, "Erro ao inicializar: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();

            // Redirecionar para Login em caso de erro
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
    }

    private void configurarClickListeners() {
        // Biblioteca
        cardBiblioteca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BibliotecaActivity.class);
                intent.putExtra("USUARIO_ID", usuarioId);
                startActivity(intent);
            }
        });

        // Boletos
        cardBoletos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BoletosActivity.class);
                intent.putExtra("USUARIO_ID", usuarioId);
                startActivity(intent);
            }
        });

        // Perfil
        cardPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PerfilActivity.class);
                intent.putExtra("USUARIO_ID", usuarioId);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_sair) {
            // Limpar preferências
            SharedPreferences prefs = getSharedPreferences("FECAPApp", MODE_PRIVATE);
            prefs.edit().clear().apply();

            // Fazer logout no Firebase
            FirebaseAuth.getInstance().signOut();

            // Redirecionar para Login
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}