package br.edu.fecap.app.model;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.Exclude;

import java.util.Date;

public class Boleto {
    @DocumentId
    private String id; // Atualizado para String para compatibilidade com Firestore
    private String idUsuario; // ID do usuário dono do boleto
    private double valor; // Valor do boleto
    private Date dataVencimento; // Data de vencimento
    private Date dataPagamento; // Data em que foi pago (pode ser nula)
    private String status; // "PENDENTE", "PAGO", "VENCIDO"
    private String codigoBarras; // Código de barras simulado
    private int mes; // Mês referente (1-12)
    private int ano; // Ano referente

    // Construtor vazio necessário para o Firestore
    public Boleto() {
    }

    // Construtor completo
    public Boleto(String id, String idUsuario, double valor, Date dataVencimento,
                  Date dataPagamento, String status, String codigoBarras,
                  int mes, int ano) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.valor = valor;
        this.dataVencimento = dataVencimento;
        this.dataPagamento = dataPagamento;
        this.status = status;
        this.codigoBarras = codigoBarras;
        this.mes = mes;
        this.ano = ano;
    }

    // Construtor para novos boletos (sem ID e data de pagamento)
    public Boleto(String idUsuario, double valor, Date dataVencimento,
                  String codigoBarras, int mes, int ano) {
        this.idUsuario = idUsuario;
        this.valor = valor;
        this.dataVencimento = dataVencimento;
        this.status = "PENDENTE";
        this.codigoBarras = codigoBarras;
        this.mes = mes;
        this.ano = ano;
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Date getDataVencimento() {
        return dataVencimento;
    }

    public void setDataVencimento(Date dataVencimento) {
        this.dataVencimento = dataVencimento;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCodigoBarras() {
        return codigoBarras;
    }

    public void setCodigoBarras(String codigoBarras) {
        this.codigoBarras = codigoBarras;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    // Método auxiliar para obter nome do mês
    @Exclude
    public String getNomeMes() {
        String[] meses = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        return meses[mes - 1]; // Arrays são 0-indexed, meses são 1-indexed
    }

    // Método auxiliar para verificar se o boleto está vencido
    @Exclude
    public boolean isVencido() {
        if ("PAGO".equals(status)) {
            return false;
        }

        Date hoje = new Date();
        return hoje.after(dataVencimento);
    }

    // Método auxiliar para atualizar status baseado na data
    @Exclude
    public void atualizarStatus() {
        if ("PAGO".equals(status)) {
            return;
        }

        if (isVencido()) {
            status = "VENCIDO";
        } else {
            status = "PENDENTE";
        }
    }

    // Método auxiliar para formatar o valor como moeda
    @Exclude
    public String getValorFormatado() {
        java.text.NumberFormat numberFormat = java.text.NumberFormat.getCurrencyInstance(
                new java.util.Locale("pt", "BR"));
        return numberFormat.format(valor);
    }
}