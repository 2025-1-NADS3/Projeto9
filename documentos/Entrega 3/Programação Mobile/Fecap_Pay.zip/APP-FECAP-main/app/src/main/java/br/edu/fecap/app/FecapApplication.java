package br.edu.fecap.app;

import android.app.Application;

import com.google.firebase.FirebaseApp;

public class FecapApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Inicializar o Firebase
        FirebaseApp.initializeApp(this);
    }
}