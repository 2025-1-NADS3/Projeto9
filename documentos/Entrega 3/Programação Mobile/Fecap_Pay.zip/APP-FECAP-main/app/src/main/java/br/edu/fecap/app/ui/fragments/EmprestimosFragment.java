package br.edu.fecap.app.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import br.edu.fecap.app.R;
import br.edu.fecap.app.api.ApiMock;
import br.edu.fecap.app.database.FirebaseHelper;
import br.edu.fecap.app.model.Emprestimo;
import br.edu.fecap.app.model.Livro;

public class EmprestimosFragment extends Fragment {

    private static final String ARG_USUARIO_ID = "usuarioId";

    private String usuarioId;
    private RecyclerView rvEmprestimos;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private List<Emprestimo> emprestimos = new ArrayList<>();
    private Map<String, Livro> livrosMap = new HashMap<>();
    private EmprestimosAdapter adapter;

    public EmprestimosFragment() {
        // Required empty public constructor
    }

    public static EmprestimosFragment newInstance(String usuarioId) {
        EmprestimosFragment fragment = new EmprestimosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_USUARIO_ID, usuarioId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            usuarioId = getArguments().getString(ARG_USUARIO_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_emprestimos, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Inicializar componentes
        rvEmprestimos = view.findViewById(R.id.rvEmprestimos);
        progressBar = view.findViewById(R.id.progressBar);
        tvEmpty = view.findViewById(R.id.tvEmpty);

        // Configurar RecyclerView
        rvEmprestimos.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new EmprestimosAdapter(emprestimos, livrosMap, this::devolverLivro);
        rvEmprestimos.setAdapter(adapter);

        // Carregar empréstimos
        carregarEmprestimos();
    }

    private void carregarEmprestimos() {
        // Mostrar progresso
        progressBar.setVisibility(View.VISIBLE);
        rvEmprestimos.setVisibility(View.GONE);
        tvEmpty.setVisibility(View.GONE);

        // Carregar todos os livros primeiro para referência
        FirebaseHelper.getInstance().getLivrosRef()
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    // Limpar e preencher mapa de livros
                    livrosMap.clear();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        Livro livro = document.toObject(Livro.class);
                        if (livro != null) {
                            livrosMap.put(document.getId(), livro);
                        }
                    }

                    // Agora que temos os livros, buscar os empréstimos do usuário
                    FirebaseHelper.getInstance().getEmprestimosRef()
                            .whereEqualTo("idUsuario", usuarioId)
                            .orderBy("dataEmprestimo", Query.Direction.DESCENDING)
                            .get()
                            .addOnSuccessListener(emprestimosResult -> {
                                // Processar resultados
                                emprestimos.clear();

                                for (DocumentSnapshot document : emprestimosResult) {
                                    Emprestimo emprestimo = document.toObject(Emprestimo.class);
                                    if (emprestimo != null) {
                                        // Verificar se o status precisa ser atualizado
                                        emprestimo.atualizarStatus();

                                        // Adicionar o livro associado
                                        Livro livro = livrosMap.get(emprestimo.getIdLivro());
                                        if (livro != null) {
                                            emprestimo.setLivro(livro);
                                        }

                                        emprestimos.add(emprestimo);
                                    }
                                }

                                // Atualizar UI
                                progressBar.setVisibility(View.GONE);
                                adapter.notifyDataSetChanged();

                                if (emprestimos.isEmpty()) {
                                    tvEmpty.setVisibility(View.VISIBLE);
                                    rvEmprestimos.setVisibility(View.GONE);
                                } else {
                                    tvEmpty.setVisibility(View.GONE);
                                    rvEmprestimos.setVisibility(View.VISIBLE);
                                }
                            })
                            .addOnFailureListener(e -> {
                                // Erro ao carregar empréstimos
                                progressBar.setVisibility(View.GONE);

                                // Usar dados mock
                                emprestimos.clear();
                                emprestimos.addAll(ApiMock.getEmprestimosMock(usuarioId));

                                // Adicionar os livros aos empréstimos
                                for (Emprestimo emprestimo : emprestimos) {
                                    Livro livro = livrosMap.get(emprestimo.getIdLivro());
                                    if (livro != null) {
                                        emprestimo.setLivro(livro);
                                    }
                                }

                                adapter.notifyDataSetChanged();

                                if (emprestimos.isEmpty()) {
                                    tvEmpty.setVisibility(View.VISIBLE);
                                    rvEmprestimos.setVisibility(View.GONE);
                                } else {
                                    tvEmpty.setVisibility(View.GONE);
                                    rvEmprestimos.setVisibility(View.VISIBLE);
                                }

                                Toast.makeText(getContext(),
                                        "Erro ao carregar empréstimos: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    // Erro ao carregar livros
                    progressBar.setVisibility(View.GONE);

                    // Usar dados mock
                    emprestimos.clear();
                    emprestimos.addAll(ApiMock.getEmprestimosMock(usuarioId));

                    // Preencher o mapa de livros com dados mock
                    for (Livro livro : ApiMock.getLivrosMock()) {
                        livrosMap.put(livro.getId(), livro);
                    }

                    // Adicionar os livros aos empréstimos
                    for (Emprestimo emprestimo : emprestimos) {
                        Livro livro = livrosMap.get(emprestimo.getIdLivro());
                        if (livro != null) {
                            emprestimo.setLivro(livro);
                        }
                    }

                    adapter.notifyDataSetChanged();

                    if (emprestimos.isEmpty()) {
                        tvEmpty.setVisibility(View.VISIBLE);
                        rvEmprestimos.setVisibility(View.GONE);
                    } else {
                        tvEmpty.setVisibility(View.GONE);
                        rvEmprestimos.setVisibility(View.VISIBLE);
                    }

                    Toast.makeText(getContext(),
                            "Erro ao carregar livros: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void devolverLivro(Emprestimo emprestimo) {
        // Verificar se empréstimo está ativo
        if (!"ATIVO".equals(emprestimo.getStatus()) && !"ATRASADO".equals(emprestimo.getStatus())) {
            Toast.makeText(getContext(), "Este livro já foi devolvido", Toast.LENGTH_SHORT).show();
            return;
        }

        // Mostrar progresso
        progressBar.setVisibility(View.VISIBLE);

        // Usar transação do Firestore para garantir consistência
        FirebaseFirestore.getInstance().runTransaction(transaction -> {
            // 1. Obter referência para o documento do empréstimo
            DocumentReference emprestimoRef = FirebaseHelper.getInstance()
                    .getEmprestimosRef().document(emprestimo.getId());

            // 2. Atualizar status do empréstimo
            Map<String, Object> updates = new HashMap<>();
            updates.put("status", "DEVOLVIDO");
            updates.put("dataDevolucaoEfetiva", new Date());
            transaction.update(emprestimoRef, updates);

            // 3. Marcar livro como disponível novamente
            DocumentReference livroRef = FirebaseHelper.getInstance()
                    .getLivrosRef().document(emprestimo.getIdLivro());
            transaction.update(livroRef, "disponivel", true);

            return null;
        }).addOnSuccessListener(aVoid -> {
            // Transação bem-sucedida
            progressBar.setVisibility(View.GONE);

            // Atualizar objetos
            emprestimo.setStatus("DEVOLVIDO");
            emprestimo.setDataDevolucaoEfetiva(new Date());

            Livro livro = livrosMap.get(emprestimo.getIdLivro());
            if (livro != null) {
                livro.setDisponivel(true);
            }

            adapter.notifyDataSetChanged();

            Toast.makeText(getContext(), "Livro devolvido com sucesso!", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(getContext(),
                    "Erro ao devolver livro: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        });
    }

    // Adapter para RecyclerView de empréstimos
    private static class EmprestimosAdapter extends RecyclerView.Adapter<EmprestimosAdapter.EmprestimoViewHolder> {

        private final List<Emprestimo> emprestimos;
        private final Map<String, Livro> livrosMap;
        private final OnDevolverClickListener listener;
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

        public interface OnDevolverClickListener {
            void onDevolverClick(Emprestimo emprestimo);
        }

        public EmprestimosAdapter(List<Emprestimo> emprestimos, Map<String, Livro> livrosMap, OnDevolverClickListener listener) {
            this.emprestimos = emprestimos;
            this.livrosMap = livrosMap;
            this.listener = listener;
        }

        @NonNull
        @Override
        public EmprestimoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_emprestimo, parent, false);
            return new EmprestimoViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull EmprestimoViewHolder holder, int position) {
            Emprestimo emprestimo = emprestimos.get(position);
            Livro livro = livrosMap.get(emprestimo.getIdLivro());
            holder.bind(emprestimo, livro, listener, dateFormat);
        }

        @Override
        public int getItemCount() {
            return emprestimos.size();
        }

        static class EmprestimoViewHolder extends RecyclerView.ViewHolder {
            private final TextView tvTituloLivro;
            private final TextView tvAutorLivro;
            private final TextView tvDataEmprestimo;
            private final TextView tvDataDevolucaoPrevista;
            private final TextView tvStatus;
            private final Button btnDevolver;

            public EmprestimoViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTituloLivro = itemView.findViewById(R.id.tvTituloLivro);
                tvAutorLivro = itemView.findViewById(R.id.tvAutorLivro);
                tvDataEmprestimo = itemView.findViewById(R.id.tvDataEmprestimo);
                tvDataDevolucaoPrevista = itemView.findViewById(R.id.tvDataDevolucaoPrevista);
                tvStatus = itemView.findViewById(R.id.tvStatus);
                btnDevolver = itemView.findViewById(R.id.btnDevolver);
            }

            public void bind(Emprestimo emprestimo, Livro livro, OnDevolverClickListener listener, SimpleDateFormat dateFormat) {
                // Título e autor do livro
                if (livro != null) {
                    tvTituloLivro.setText(livro.getTitulo());
                    tvAutorLivro.setText(livro.getAutor());
                } else {
                    tvTituloLivro.setText("Livro ID: " + emprestimo.getIdLivro());
                    tvAutorLivro.setText("Autor desconhecido");
                }

                // Datas
                tvDataEmprestimo.setText("Empréstimo: " + dateFormat.format(emprestimo.getDataEmprestimo()));
                tvDataDevolucaoPrevista.setText("Devolução: " + dateFormat.format(emprestimo.getDataDevolucaoPrevista()));

                // Status
                String status = emprestimo.getStatus();
                tvStatus.setText(status);

                if ("ATIVO".equals(status)) {
                    tvStatus.setTextColor(itemView.getContext().getColor(R.color.fecap_green));
                    btnDevolver.setVisibility(View.VISIBLE);
                    btnDevolver.setEnabled(true);
                } else if ("ATRASADO".equals(status)) {
                    tvStatus.setTextColor(itemView.getContext().getColor(android.R.color.holo_red_dark));
                    btnDevolver.setVisibility(View.VISIBLE);
                    btnDevolver.setEnabled(true);
                } else {
                    tvStatus.setTextColor(itemView.getContext().getColor(R.color.gray));
                    btnDevolver.setVisibility(View.GONE);
                }

                btnDevolver.setOnClickListener(v -> listener.onDevolverClick(emprestimo));
            }
        }
    }
}