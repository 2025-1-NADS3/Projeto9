package br.edu.fecap.app.model;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.Exclude;

public class Livro {
    @DocumentId
    private String id; // Atualizado para String para compatibilidade com Firestore
    private String titulo;
    private String autor;
    private String descricao;
    private boolean disponivel;
    private String imagemUrl; // Para armazenar o caminho da imagem de capa

    // Construtor vazio necessário para o Firestore
    public Livro() {
    }

    // Construtor completo
    public Livro(String id, String titulo, String autor, String descricao, boolean disponivel, String imagemUrl) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.descricao = descricao;
        this.disponivel = disponivel;
        this.imagemUrl = imagemUrl;
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    public String getImagemUrl() {
        return imagemUrl;
    }

    public void setImagemUrl(String imagemUrl) {
        this.imagemUrl = imagemUrl;
    }

    // Método auxiliar para obter o recurso de imagem (não armazenado no Firestore)
    @Exclude
    public int getImageResourceId(android.content.Context context) {
        if (imagemUrl != null && !imagemUrl.isEmpty()) {
            return context.getResources().getIdentifier(
                    imagemUrl, "drawable", context.getPackageName());
        }
        return 0; // Retorna 0 se não encontrar o recurso
    }
}

