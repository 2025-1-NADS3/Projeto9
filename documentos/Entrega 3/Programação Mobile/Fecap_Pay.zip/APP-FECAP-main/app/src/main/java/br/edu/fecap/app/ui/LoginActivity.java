package br.edu.fecap.app.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import br.edu.fecap.app.MainActivity;
import br.edu.fecap.app.R;
import br.edu.fecap.app.database.FirebaseHelper;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail;
    private TextInputEditText etSenha;
    private Button btnLogin;
    private Button btnCadastro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializar componentes
        etEmail = findViewById(R.id.etEmail);
        etSenha = findViewById(R.id.etSenha);
        btnLogin = findViewById(R.id.btnLogin);
        btnCadastro = findViewById(R.id.btnCadastro);

        // Configurar listener do botão de login
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String senha = etSenha.getText().toString().trim();

                // Validação simples
                if (email.isEmpty()) {
                    etEmail.setError("Por favor, insira seu e-mail");
                    return;
                }

                if (senha.isEmpty()) {
                    etSenha.setError("Por favor, insira sua senha");
                    return;
                }

                // Realizar login
                realizarLogin(email, senha);
            }
        });

        // Configurar listener do botão de cadastro
        btnCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abrir tela de cadastro
                Intent intent = new Intent(LoginActivity.this, CadastroActivity.class);
                startActivity(intent);
            }
        });
    }

    private void realizarLogin(String email, String senha) {
        // Mostrar progresso
        btnLogin.setEnabled(false);
        btnLogin.setText(R.string.entrando);

        // Usar o Firebase Auth para login
        FirebaseHelper.getInstance().fazerLogin(email, senha)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Login bem-sucedido
                        String uid = FirebaseHelper.getInstance().getUsuarioAtual().getUid();

                        // Buscar dados do usuário no Firestore
                        FirebaseHelper.getInstance().getUsuarioPorUID(uid)
                                .addOnSuccessListener(documentSnapshot -> {
                                    // Salvar ID do usuário em SharedPreferences
                                    SharedPreferences prefs = getSharedPreferences("FECAPApp", MODE_PRIVATE);
                                    prefs.edit().putString("USUARIO_ID", uid).apply();

                                    // Abrir tela principal
                                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(LoginActivity.this,
                                            "Erro ao carregar dados do usuário: " + e.getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                    btnLogin.setEnabled(true);
                                    btnLogin.setText(R.string.entrar);
                                });
                    } else {
                        // Login falhou
                        Toast.makeText(LoginActivity.this,
                                "E-mail ou senha incorretos",
                                Toast.LENGTH_SHORT).show();
                        btnLogin.setEnabled(true);
                        btnLogin.setText(R.string.entrar);
                    }
                });
    }
}