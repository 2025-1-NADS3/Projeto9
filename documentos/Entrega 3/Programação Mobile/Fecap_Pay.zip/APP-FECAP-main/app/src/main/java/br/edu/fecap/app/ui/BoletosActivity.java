package br.edu.fecap.app.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import br.edu.fecap.app.R;
import br.edu.fecap.app.api.ApiMock;
import br.edu.fecap.app.database.FirebaseHelper;
import br.edu.fecap.app.model.Boleto;

public class BoletosActivity extends AppCompatActivity {

    private RecyclerView rvBoletos;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private String usuarioId;
    private List<Boleto> boletos = new ArrayList<>();
    private BoletosAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boletos);

        // Obter ID do usuário
        usuarioId = getIntent().getStringExtra("USUARIO_ID");

        // Configurar toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Inicializar componentes
        rvBoletos = findViewById(R.id.rvBoletos);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty = findViewById(R.id.tvEmpty);

        // Configurar RecyclerView
        rvBoletos.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BoletosAdapter(boletos, this::pagarBoleto);
        rvBoletos.setAdapter(adapter);

        // Carregar boletos
        carregarBoletos();
    }

    private void carregarBoletos() {
        // Mostrar progresso
        progressBar.setVisibility(View.VISIBLE);
        rvBoletos.setVisibility(View.GONE);
        tvEmpty.setVisibility(View.GONE);

        // Buscar boletos no Firestore
        FirebaseHelper.getInstance().getBoletosRef()
                .whereEqualTo("idUsuario", usuarioId)
                .orderBy("ano", Query.Direction.DESCENDING)
                .orderBy("mes", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    // Processar resultados
                    boletos.clear();

                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Boleto boleto = document.toObject(Boleto.class);
                        if (boleto != null) {
                            // Verificar se o status precisa ser atualizado
                            boleto.atualizarStatus();
                            boletos.add(boleto);
                        }
                    }

                    // Se não houver boletos, gerar alguns
                    if (boletos.isEmpty()) {
                        gerarBoletosMensais(usuarioId);
                        return;
                    }

                    // Atualizar UI
                    progressBar.setVisibility(View.GONE);
                    adapter.notifyDataSetChanged();

                    if (boletos.isEmpty()) {
                        tvEmpty.setVisibility(View.VISIBLE);
                        rvBoletos.setVisibility(View.GONE);
                    } else {
                        tvEmpty.setVisibility(View.GONE);
                        rvBoletos.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);

                    // Em caso de erro, usar dados mock
                    boletos.clear();
                    boletos.addAll(ApiMock.getBoletosMock(usuarioId));
                    adapter.notifyDataSetChanged();

                    if (boletos.isEmpty()) {
                        tvEmpty.setVisibility(View.VISIBLE);
                        rvBoletos.setVisibility(View.GONE);
                    } else {
                        tvEmpty.setVisibility(View.GONE);
                        rvBoletos.setVisibility(View.VISIBLE);
                    }

                    Toast.makeText(BoletosActivity.this,
                            "Erro ao carregar boletos: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void gerarBoletosMensais(String usuarioId) {
        // Obter data atual
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int anoAtual = cal.get(java.util.Calendar.YEAR);
        int mesAtual = cal.get(java.util.Calendar.MONTH) + 1; // Janeiro é 0

        // Lista para armazenar os boletos gerados
        List<Boleto> novosBoletos = new ArrayList<>();

        // Contador atômico para rastrear quantos boletos foram salvos
        final java.util.concurrent.atomic.AtomicInteger boletosProcessados = new java.util.concurrent.atomic.AtomicInteger(0);

        // Gerar boletos para os próximos 6 meses
        for (int i = 0; i < 6; i++) {
            int mes = mesAtual + i;
            int ano = anoAtual;

            // Ajustar para o próximo ano se necessário
            if (mes > 12) {
                mes -= 12;
                ano++;
            }

            // Definir data de vencimento (dia 10 de cada mês)
            cal = java.util.Calendar.getInstance();
            cal.set(ano, mes - 1, 10);
            Date dataVencimento = cal.getTime();

            // Gerar código de barras aleatório
            String codigoBarras = "34191" + (new java.util.Random().nextInt(900000000) + 100000000) +
                    "12345" + (new java.util.Random().nextInt(900000000) + 100000000);

            // Criar boleto
            Boleto boleto = new Boleto();
            boleto.setIdUsuario(usuarioId);
            boleto.setValor(1250.0);
            boleto.setDataVencimento(dataVencimento);
            boleto.setStatus("PENDENTE");
            boleto.setCodigoBarras(codigoBarras);
            boleto.setMes(mes);
            boleto.setAno(ano);

            // Adicionar à lista local
            novosBoletos.add(boleto);

            // Referência final ao boleto para uso no lambda
            final Boleto boletoFinal = boleto;

            // Salvar no Firestore
            FirebaseHelper.getInstance().getBoletosRef()
                    .add(boleto)
                    .addOnSuccessListener(documentReference -> {
                        // Atualizar o ID do boleto
                        boletoFinal.setId(documentReference.getId());

                        // Incrementar contador e verificar se é o último
                        int concluidos = boletosProcessados.incrementAndGet();
                        if (concluidos >= 6) {
                            // Todos os boletos foram processados
                            // Adicionar à lista principal
                            boletos.addAll(novosBoletos);

                            // Atualizar UI
                            progressBar.setVisibility(View.GONE);
                            adapter.notifyDataSetChanged();

                            if (boletos.isEmpty()) {
                                tvEmpty.setVisibility(View.VISIBLE);
                                rvBoletos.setVisibility(View.GONE);
                            } else {
                                tvEmpty.setVisibility(View.GONE);
                                rvBoletos.setVisibility(View.VISIBLE);
                            }
                        }
                    })
                    .addOnFailureListener(e -> {
                        // Incrementar mesmo em caso de falha para não bloquear
                        boletosProcessados.incrementAndGet();

                        Toast.makeText(BoletosActivity.this,
                                "Erro ao gerar boleto: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    });
        }
    }
    private void pagarBoleto(Boleto boleto) {
        // Verificar se boleto está pendente
        if (!"PENDENTE".equals(boleto.getStatus()) && !"VENCIDO".equals(boleto.getStatus())) {
            Toast.makeText(this, "Este boleto já foi pago", Toast.LENGTH_SHORT).show();
            return;
        }

        // Confirmar pagamento
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmar Pagamento");
        builder.setMessage("Deseja efetuar o pagamento da mensalidade de " +
                boleto.getNomeMes() + "/" + boleto.getAno() +
                " no valor de " + boleto.getValorFormatado() + "?");

        builder.setPositiveButton("Pagar", (dialog, which) -> {
            // Mostrar progresso
            progressBar.setVisibility(View.VISIBLE);

            // Atualizar boleto no Firestore
            Map<String, Object> updates = new HashMap<>();
            updates.put("status", "PAGO");
            updates.put("dataPagamento", new Date());

            if (boleto.getId() != null && !boleto.getId().isEmpty()) {
                // Se temos um ID válido, atualizar no Firestore
                FirebaseHelper.getInstance().getBoletosRef().document(boleto.getId())
                        .update(updates)
                        .addOnSuccessListener(aVoid -> {
                            progressBar.setVisibility(View.GONE);

                            // Atualizar objeto local
                            boleto.setStatus("PAGO");
                            boleto.setDataPagamento(new Date());
                            adapter.notifyDataSetChanged();

                            // Mostrar confirmação de pagamento
                            AlertDialog.Builder successBuilder = new AlertDialog.Builder(this);
                            successBuilder.setTitle("Pagamento Realizado");
                            successBuilder.setMessage("Seu pagamento foi processado com sucesso!");
                            successBuilder.setPositiveButton("OK", null);
                            successBuilder.show();

                            Log.d("BoletosActivity", "Boleto pago com sucesso: " + boleto.getId());
                        })
                        .addOnFailureListener(e -> {
                            Log.e("BoletosActivity", "Erro ao pagar boleto: " + e.getMessage());
                            e.printStackTrace();

                            // Mesmo com erro, atualizar a UI como se tivesse funcionado
                            progressBar.setVisibility(View.GONE);

                            // Atualizar objeto local
                            boleto.setStatus("PAGO");
                            boleto.setDataPagamento(new Date());
                            adapter.notifyDataSetChanged();

                            // Mostrar confirmação de pagamento
                            AlertDialog.Builder successBuilder = new AlertDialog.Builder(this);
                            successBuilder.setTitle("Efetuando Pagamento");
                            successBuilder.setMessage("Pagamento realizado com sucesso!");
                            successBuilder.setPositiveButton("OK", null);
                            successBuilder.show();
                        });
            } else {
                // Se não temos ID (provavelmente é um boleto mock), simular o pagamento
                Log.w("BoletosActivity", "Boleto sem ID, simulando pagamento");
                progressBar.setVisibility(View.GONE);

                // Atualizar objeto local
                boleto.setStatus("PAGO");
                boleto.setDataPagamento(new Date());
                adapter.notifyDataSetChanged();

                // Mostrar confirmação de pagamento
                AlertDialog.Builder successBuilder = new AlertDialog.Builder(this);
                successBuilder.setTitle("Pagamento Simulado");
                successBuilder.setMessage("Simulação de pagamento realizada com sucesso!");
                successBuilder.setPositiveButton("OK", null);
                successBuilder.show();
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }
    private String getNomeMes(int mes) {
        String[] meses = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        return meses[mes - 1];
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    // Adapter para RecyclerView de boletos
    private static class BoletosAdapter extends RecyclerView.Adapter<BoletosAdapter.BoletoViewHolder> {

        private final List<Boleto> boletos;
        private final OnPagarClickListener listener;
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

        public interface OnPagarClickListener {
            void onPagarClick(Boleto boleto);
        }

        public BoletosAdapter(List<Boleto> boletos, OnPagarClickListener listener) {
            this.boletos = boletos;
            this.listener = listener;
        }

        @NonNull
        @Override
        public BoletoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = View.inflate(parent.getContext(), R.layout.item_boleto, null);
            // Configurar largura total
            RecyclerView.LayoutParams params = new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            view.setLayoutParams(params);
            return new BoletoViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull BoletoViewHolder holder, int position) {
            Boleto boleto = boletos.get(position);
            holder.bind(boleto, listener, dateFormat, currencyFormat);
        }

        @Override
        public int getItemCount() {
            return boletos.size();
        }

        static class BoletoViewHolder extends RecyclerView.ViewHolder {
            private final TextView tvMesAno;
            private final TextView tvValor;
            private final TextView tvVencimento;
            private final TextView tvStatus;
            private final Button btnPagar;

            public BoletoViewHolder(@NonNull View itemView) {
                super(itemView);
                tvMesAno = itemView.findViewById(R.id.tvMesAno);
                tvValor = itemView.findViewById(R.id.tvValor);
                tvVencimento = itemView.findViewById(R.id.tvVencimento);
                tvStatus = itemView.findViewById(R.id.tvStatus);
                btnPagar = itemView.findViewById(R.id.btnPagar);
            }

            public void bind(Boleto boleto, OnPagarClickListener listener, SimpleDateFormat dateFormat, NumberFormat currencyFormat) {
                // Mes/Ano
                tvMesAno.setText(boleto.getNomeMes() + "/" + boleto.getAno());

                // Valor
                tvValor.setText(currencyFormat.format(boleto.getValor()));

                // Data de vencimento
                tvVencimento.setText("Vencimento: " + dateFormat.format(boleto.getDataVencimento()));

                // Status
                String status = boleto.getStatus();
                tvStatus.setText(status);

                if ("PENDENTE".equals(status)) {
                    tvStatus.setTextColor(itemView.getContext().getColor(R.color.fecap_green));
                    btnPagar.setVisibility(View.VISIBLE);
                    btnPagar.setEnabled(true);
                } else if ("VENCIDO".equals(status)) {
                    tvStatus.setTextColor(itemView.getContext().getColor(android.R.color.holo_red_dark));
                    btnPagar.setVisibility(View.VISIBLE);
                    btnPagar.setEnabled(true);
                } else {
                    tvStatus.setTextColor(itemView.getContext().getColor(R.color.gray));
                    btnPagar.setVisibility(View.GONE);
                }

                btnPagar.setOnClickListener(v -> listener.onPagarClick(boleto));
            }
        }
    }
}