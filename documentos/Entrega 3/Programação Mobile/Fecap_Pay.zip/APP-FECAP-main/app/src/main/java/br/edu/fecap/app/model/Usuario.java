package br.edu.fecap.app.model;

public class Usuario {
    private String id; // Agora é String para compatibilidade com UID do Firebase
    private String nome;
    private String email;
    private String matricula;
    private String senha; // Será usada apenas no processo de cadastro, não armazenada

    // Construtor padrão necessário para o Firestore
    public Usuario() {
    }

    // Construtor principal
    public Usuario(String id, String nome, String email, String matricula) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.matricula = matricula;
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}