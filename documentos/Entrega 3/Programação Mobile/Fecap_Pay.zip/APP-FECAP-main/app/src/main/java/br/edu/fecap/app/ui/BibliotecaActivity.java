package br.edu.fecap.app.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import br.edu.fecap.app.R;
import br.edu.fecap.app.ui.fragments.EmprestimosFragment;
import br.edu.fecap.app.ui.fragments.LivrosFragment;

public class BibliotecaActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private String usuarioId; // Tipo String para compatibilidade com Firebase

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biblioteca);

        try {
            // Obter ID do usuário (sempre como String)
            if (getIntent().hasExtra("USUARIO_ID")) {
                usuarioId = getIntent().getStringExtra("USUARIO_ID");
            } else {
                // Valor padrão para desenvolvimento
                usuarioId = "user123";
            }

            // Configurar toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            // Inicializar componentes
            viewPager = findViewById(R.id.viewPager);
            tabLayout = findViewById(R.id.tabLayout);

            // Configurar ViewPager com adapter
            BibliotecaPagerAdapter pagerAdapter = new BibliotecaPagerAdapter(this);
            viewPager.setAdapter(pagerAdapter);

            // Conectar TabLayout com ViewPager
            new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
                switch (position) {
                    case 0:
                        tab.setText(R.string.livros_disponiveis);
                        break;
                    case 1:
                        tab.setText(R.string.meus_emprestimos);
                        break;
                }
            }).attach();

        } catch (Exception e) {
            e.printStackTrace();
            finish(); // Fechar activity em caso de erro
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    // Adapter para ViewPager
    private class BibliotecaPagerAdapter extends FragmentStateAdapter {

        public BibliotecaPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
            super(fragmentActivity);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            // Criar fragmentos de acordo com a posição
            switch (position) {
                case 0:
                    return LivrosFragment.newInstance(usuarioId);
                case 1:
                    return EmprestimosFragment.newInstance(usuarioId);
                default:
                    return LivrosFragment.newInstance(usuarioId);
            }
        }

        @Override
        public int getItemCount() {
            return 2; // Número de abas
        }
    }
}