package br.fecapads.pi_entrega;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private MainActivity.DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new MainActivity.DatabaseHelper(this);

        // Exibir todos os usuários cadastrados no banco de dados
        displayAllUsers();

        EditText editRa = findViewById(R.id.edit_ra);  // RA no login
        EditText editPassword = findViewById(R.id.edit_password);
        Button btnLogin = findViewById(R.id.btn_login);
        TextView tvSignupLink = findViewById(R.id.tv_signup_link);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ra = editRa.getText().toString();
                String password = editPassword.getText().toString();

                if (ra.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                } else {
                    Cursor cursor = databaseHelper.getReadableDatabase().rawQuery(
                            "SELECT * FROM Users WHERE ra = ? AND password = ?",
                            new String[]{ra, password});

                    if (cursor != null && cursor.moveToFirst()) {
                        String firstName = cursor.getString(cursor.getColumnIndexOrThrow("firstName"));
                        String raValue = cursor.getString(cursor.getColumnIndexOrThrow("ra"));

                        Log.d("LoginActivity", "Login bem-sucedido! RA: " + raValue + ", Nome: " + firstName);

                        // Redirecionar para a tela de perfil com dados
                        Intent intent = new Intent(LoginActivity.this, ProfileActivity.class);
                        intent.putExtra("firstName", firstName);  // Passa o nome do usuário
                        intent.putExtra("ra", raValue);  // Passa o RA do usuário
                        startActivity(intent);
                        finish();

                    } else {
                        Toast.makeText(LoginActivity.this, "RA ou senha incorretos.", Toast.LENGTH_SHORT).show();
                        Log.e("LoginActivity", "Falha na autenticação: RA = " + ra);
                    }

                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        });

        tvSignupLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    // Método para exibir todos os usuários cadastrados no banco de dados
    private void displayAllUsers() {
        Cursor cursor = databaseHelper.getReadableDatabase().rawQuery("SELECT * FROM Users", null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String ra = cursor.getString(cursor.getColumnIndexOrThrow("ra"));
                String firstName = cursor.getString(cursor.getColumnIndexOrThrow("firstName"));
                String lastName = cursor.getString(cursor.getColumnIndexOrThrow("lastName"));
                String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
                String password = cursor.getString(cursor.getColumnIndexOrThrow("password"));

                Log.d("LoginActivity", "Usuário: RA = " + ra + ", Nome = " + firstName + " " + lastName +
                        ", Email = " + email + ", Senha = " + password);
            }
        } else {
            Log.d("LoginActivity", "Nenhum usuário encontrado no banco de dados.");
        }
        cursor.close();
    }
}
