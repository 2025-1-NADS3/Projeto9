package br.fecapads.pi_entrega;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editFirstName, editLastName, editEmail, editRA, editPassword, editConfirmPassword;
    Button btnSend;
    ImageButton btnBack;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Mapeando IDs dos campos
        editFirstName = findViewById(R.id.etNome);
        editLastName = findViewById(R.id.etSobrenome);
        editEmail = findViewById(R.id.etEmail);
        editRA = findViewById(R.id.etRA);
        editPassword = findViewById(R.id.etSenha);
        editConfirmPassword = findViewById(R.id.etConfirmaSenha);
        btnSend = findViewById(R.id.btnEnviar);
        btnBack = findViewById(R.id.btnBack);

        databaseHelper = new DatabaseHelper(this);

        // Ação botão "Voltar"
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Encerra esta Activity e volta à anterior
            }
        });

        // Ação botão "Enviar"
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String firstName = editFirstName.getText().toString().trim();
                String lastName = editLastName.getText().toString().trim();
                String email = editEmail.getText().toString().trim();
                String ra = editRA.getText().toString().trim();
                String password = editPassword.getText().toString();
                String confirmPassword = editConfirmPassword.getText().toString();

                if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || ra.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(MainActivity.this, "As senhas não coincidem.", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isInserted = databaseHelper.insertUser(firstName, lastName, email, ra, password);
                if (isInserted) {
                    Toast.makeText(MainActivity.this, "Usuário registrado com sucesso!", Toast.LENGTH_SHORT).show();
                    Log.i("UserRegistration", "Usuário registrado: " + firstName + " " + lastName + ", Email: " + email + ", RA: " + ra);
                    databaseHelper.getAllUsers(); // logar todos os dados
                    clearFields();

                    // Redirecionar para LoginActivity e passar email preenchido
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    intent.putExtra("email", email);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Erro ao registrar usuário.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void clearFields() {
        editFirstName.setText("");
        editLastName.setText("");
        editEmail.setText("");
        editRA.setText("");
        editPassword.setText("");
        editConfirmPassword.setText("");
    }

    public static class DatabaseHelper extends SQLiteOpenHelper {
        public static final String DATABASE_NAME = "UserDB.db";
        public static final int DATABASE_VERSION = 1;

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS Users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "firstName TEXT, " +
                    "lastName TEXT, " +
                    "email TEXT, " +
                    "ra TEXT, " +
                    "password TEXT)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS Users");
            onCreate(db);
        }

        public boolean insertUser(String firstName, String lastName, String email, String ra, String password) {
            SQLiteDatabase db = this.getWritableDatabase();
            db.execSQL("INSERT INTO Users (firstName, lastName, email, ra, password) VALUES (?, ?, ?, ?, ?)",
                    new Object[]{firstName, lastName, email, ra, password});
            return true;
        }

        public void getAllUsers() {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM Users", null);
            if (cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(0);
                    String firstName = cursor.getString(1);
                    String lastName = cursor.getString(2);
                    String email = cursor.getString(3);
                    String ra = cursor.getString(4);
                    String password = cursor.getString(5);
                    Log.d("DatabaseHelper", "ID: " + id + ", Nome: " + firstName + " " + lastName +
                            ", Email: " + email + ", RA: " + ra + ", Senha: " + password);
                } while (cursor.moveToNext());
            } else {
                Log.d("DatabaseHelper", "Nenhum usuário encontrado no banco de dados.");
            }
            cursor.close();
        }
    }
}
