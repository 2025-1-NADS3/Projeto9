package br.fecapads.pi_entrega;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    TextView tvWelcome, tvRa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Referências para os TextViews
        tvWelcome = findViewById(R.id.tv_user_name);  // Atualizando o TextView para o nome
        tvRa = findViewById(R.id.tv_user_ra);  // Atualizando o TextView para o RA

        // Recuperar dados do Intent
        Intent intent = getIntent();
        String firstName = intent.getStringExtra("firstName");
        String ra = intent.getStringExtra("ra");

        // Exibir na tela
        tvWelcome.setText(firstName);  // Exibe o nome
        tvRa.setText("RA: " + ra);  // Exibe o RA
    }
}
